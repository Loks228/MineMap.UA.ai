
# Инструкция: Блокировка устройств и ведение истории входов

## Таблица login_history
```sql
CREATE TABLE login_history (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER    NOT NULL REFERENCES users(id),
  device_id      TEXT       NOT NULL,
  ip_address     INET       NOT NULL,
  user_agent     TEXT,
  event_type     VARCHAR(16) NOT NULL,  -- 'register' | 'login'
  event_ts       TIMESTAMPTZ NOT NULL DEFAULT now()
);
```
- Записывайте при регистрации и при входе: `device_id`, `ip_address`, `user_agent`, `event_type`.

## Таблица banned_devices
```sql
CREATE TABLE banned_devices (
  device_id  TEXT PRIMARY KEY,
  banned_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  reason     TEXT
);
```
- При третьем неподтверждённом событии добавлять `device_id` в эту таблицу.

## Логика проверки при регистрации/входе
```pseudo
if banned_devices.exists(device_id) {
  return error("Ваше устройство заблокировано");
}
```

## UX и апелляции
- Показывать пользователю сообщение об блокировке и ссылку «Обжаловать».
- Админ-панель: просмотр и ручная разблокировка в таблице `banned_devices`.

## Безопасность и конфиденциальность
- Хранить `device_id` и логи в защищённой БД.
- Указать в политике конфиденциальности сбор device fingerprint для безопасности.
